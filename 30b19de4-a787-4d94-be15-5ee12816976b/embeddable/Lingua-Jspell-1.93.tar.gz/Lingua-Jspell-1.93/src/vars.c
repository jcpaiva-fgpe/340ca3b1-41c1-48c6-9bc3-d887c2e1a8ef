#define MAIN
#include "jspell.h"

/*
   Hack to make ExtUtils::CBuilder compile a .DLL file

   I still need to test it :) 

   in fact, I think I can delete this already...
*/
int boot_jspell () { return 0; } 

