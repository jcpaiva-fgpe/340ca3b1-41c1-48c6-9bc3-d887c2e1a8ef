
static char * Version_ID[] = {
    " International Jspell Version " VERSION,
    " Copyright (c), 1994-2008 by Ulisses Pinto & Jos� Jo�o Almeida",
    " ",
    " Based on ispell, Copyright (c), 1983, by Pace Willisson",
    " International version Copyright (c) 1987, 1988, 1990, 1991, 1992, 1993,",
    " by Geoff Kuenning, Granada Hills, CA.  All rights reserved.",
    NULL
};

